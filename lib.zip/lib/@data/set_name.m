function [dat] = set_name(dat,nam)
 
%   DATA=set_name(DATA,NAME) sets the name of data object to NAME

dat.algorithm.name=nam;

